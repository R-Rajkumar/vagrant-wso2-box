Add following jar files to support private-paas clustering extension

activemq_client_5.10.0_1.0.0.jar
geronimo_j2ee_management_1.1_spec_1.0.1_1.0.0.jar
hawtbuf_1.9_1.0.0.jar
org.apache.commons.lang3_3.1.0.jar
org.apache.stratos.common-4.1.0.jar
org.apache.stratos.messaging-4.1.0.jar
private-paas-membership-scheme-4.1.0-SNAPSHOT.jar

More info - https://github.com/imesh/stratos-membership-scheme/tree/master/carbon-4.2.0