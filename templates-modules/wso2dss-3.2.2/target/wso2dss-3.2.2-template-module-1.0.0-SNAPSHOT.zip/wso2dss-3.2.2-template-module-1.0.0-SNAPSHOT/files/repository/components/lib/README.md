Add following jar files

mysql connector jar file 
org.wso2.carbon.server-4.2.0.jar - Comes with Kernal patch 12
