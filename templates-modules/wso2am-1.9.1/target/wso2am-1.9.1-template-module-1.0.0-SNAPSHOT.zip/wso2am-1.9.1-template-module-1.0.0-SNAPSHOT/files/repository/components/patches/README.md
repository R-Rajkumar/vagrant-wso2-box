Add patch 12 for private-paas clustering extension
